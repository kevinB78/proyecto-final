import paypalrestsdk
paypalrestsdk.configure({
    "mode": "sandbox",  # Cambia a "live" para producción
    "client_id": "AfEGV22oSQ_WKWl2vzmJpeju4EM-ffEdF3NR0G_45Ips0qh8bA4z1ccd4xpSEPbleDopJb3nAMTpuD4q",
    "client_secret": "ELStBDLEigStN0OAc4MrAbGIM-TcFPKv1iCa-D_hw7VaafEDPr3qH26rIldWYdz1f9LHeY1vjpg6A2_r"
})